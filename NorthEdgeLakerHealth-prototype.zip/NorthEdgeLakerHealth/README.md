# NorthEdge Laker Health — Android prototype

This native Android prototype now presents a simple wellness dashboard, Bluetooth watch connection controls, and a collapsible diagnostics panel. It shows heart rate, steps, blood oxygen, and sleep as unavailable until the watch protocol is identified and real readings can be decoded.

## Current status

The app can scan for nearby Bluetooth Low Energy devices, connect to a selected device (look for `XWatch Lite`), discover GATT services, attempt readable characteristics, and subscribe to notify/indicate characteristics. It logs returned bytes in hexadecimal so the watch's protocol can be investigated.

This remains a **Bluetooth discovery prototype, not yet a complete health tracker**. The watch's private data protocol and any pairing/authentication handshake are not confirmed. The app does not fabricate steps, sleep, heart-rate, blood-oxygen, or calorie values. Those readings can only appear after the protocol is decoded and tested against the physical watch.

## Build

Open this folder in Android Studio (current stable version), allow Gradle sync, then run on the Samsung phone. It uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Java 17 bytecode targets, and Android SDK platform 35.

To make an APK in Android Studio: **Build → Build Bundle(s) / APK(s) → Build APK(s)**. For testing, install on your own phone and grant nearby-device/Bluetooth permissions.

## Test procedure

1. Charge the watch and keep it beside the phone.
2. Turn on Bluetooth on the phone.
3. If possible, make the watch discoverable; close Sports+ on any other phone.
4. Tap **Scan for watch** and choose `XWatch Lite` or the matching device name.
5. Wait for services and raw reads/notifications to appear under **Connection details**.
6. Save or share the log so the characteristic UUIDs and sample bytes can be decoded in the next iteration.

## Safety and privacy

The prototype does not upload data to a server. It only shows Bluetooth diagnostic values on screen. It is not a medical device and must not be used for diagnosis or emergency monitoring.
