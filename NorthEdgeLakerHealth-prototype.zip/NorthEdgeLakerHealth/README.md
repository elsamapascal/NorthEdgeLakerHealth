# NorthEdge Laker Health — Android prototype

This is the first native Android project for a Samsung phone. It scans Bluetooth Low Energy devices, lets you select a device (look for `XWatch Lite`), connects over GATT, lists services/characteristics, attempts readable characteristics, and subscribes to notify/indicate characteristics. It logs returned bytes in hexadecimal so the watch's protocol can be identified.

## Important status

This is a **Bluetooth discovery prototype, not yet a complete health tracker**. The watch's private data protocol and any pairing/authentication handshake are not confirmed. The prototype does not fabricate steps, sleep, heart-rate, or calorie values. Those screens can only show real values after the protocol is decoded and tested against the physical watch.

## Build

Open this folder in Android Studio (current stable version), allow Gradle sync, then run on the Samsung phone. It uses Android Gradle Plugin 8.7.3 and Kotlin 2.0.21. The Android SDK platform 35 is required.

To make an APK in Android Studio: **Build → Build Bundle(s) / APK(s) → Build APK(s)**. For testing, install on your own phone and grant nearby-device/Bluetooth permissions.

## Test procedure

1. Charge the watch and keep it beside the phone.
2. Turn on Bluetooth on the phone.
3. If possible, make the watch discoverable; close Sports+ on any other phone.
4. Tap **Scan for watch** and choose `XWatch Lite` or the matching device name.
5. Wait for services and raw reads/notifications to appear in the diagnostics panel.
6. Save or share the log so the characteristic UUIDs and sample bytes can be decoded in the next iteration.

## Safety and privacy

The prototype does not upload data to a server. It only shows Bluetooth diagnostic values on screen. It is not a medical device and must not be used for diagnosis or emergency monitoring.
