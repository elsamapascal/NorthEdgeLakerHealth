package com.northedge.lakerhealth

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.UUID

/**
 * NorthEdge Laker Health prototype.
 * Scans for BLE devices, connects to a selected device, discovers GATT services,
 * and logs readable characteristic values/notifications as hex. The Laker's
 * data protocol is not yet known, so this intentionally does not invent health readings.
 */
class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var deviceList: LinearLayout
    private lateinit var logView: TextView
    private lateinit var diagnosticsPanel: LinearLayout
    private lateinit var diagnosticsToggle: TextView
    private var diagnosticsExpanded = false
    private val handler = Handler(Looper.getMainLooper())
    private val found = linkedMapOf<String, BluetoothDevice>()
    private var scanner = false
    private var gatt: BluetoothGatt? = null
    private var selectedDevice: BluetoothDevice? = null
    private var bluetoothAdapter: BluetoothAdapter? = null

    private val neededPermissions: Array<String>
        get() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) arrayOf(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_CONNECT
        ) else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = manager.adapter
        buildUi()
        if (!hasPermissions()) requestPermissions(neededPermissions, 501)
        else refreshBluetoothStatus()
    }

    private fun buildUi() {
        val screen = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(0xFFF3F6FB.toInt())
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(28))
        }
        screen.addView(root)
        root.addView(TextView(this).apply {
            text = "NorthEdge"
            textSize = 28f
            setTextColor(0xFF152641.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "LAKER HEALTH"
            textSize = 12f
            letterSpacing = 0.12f
            setTextColor(0xFF59708B.toInt())
            setPadding(0, dp(2), 0, dp(20))
        })

        status = TextView(this).apply {
            text = "Checking Bluetooth…"
            textSize = 15f
            setTextColor(0xFF173B61.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = roundedBackground(0xFFE4F0FC.toInt(), 0xFFD3E4F5.toInt())
        }
        root.addView(status, spacedParams(14))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(makeButton("Scan for watch") { startScan() }, LinearLayout.LayoutParams(0, dp(52), 1f).apply { rightMargin = dp(6) })
        actions.addView(makeButton("Disconnect") { disconnect() }, LinearLayout.LayoutParams(0, dp(52), 1f).apply { leftMargin = dp(6) })
        root.addView(actions, spacedParams(24))

        root.addView(sectionTitle("Today at a glance"), spacedParams(4))
        root.addView(TextView(this).apply {
            text = "Your watch readings will appear here when available."
            textSize = 14f
            setTextColor(0xFF66758A.toInt())
        }, spacedParams(14))
        root.addView(metricRow(metricCard("Heart rate", "BPM"), metricCard("Steps", "steps")), spacedParams(10))
        root.addView(metricRow(metricCard("Blood oxygen", "SpO₂"), metricCard("Sleep", "hours")), spacedParams(12))
        root.addView(TextView(this).apply {
            text = "This prototype has connected to the watch, but its health-data format is not decoded yet. Readings stay blank until real values are available."
            textSize = 13f
            setTextColor(0xFF475D74.toInt())
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = roundedBackground(0xFFEAF0F6.toInt(), 0xFFDCE5EE.toInt())
        }, spacedParams(24))

        root.addView(sectionTitle("Nearby watches"), spacedParams(8))
        root.addView(TextView(this).apply {
            text = "Tap a device to connect."
            textSize = 14f
            setTextColor(0xFF66758A.toInt())
        }, spacedParams(10))
        deviceList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(deviceList, spacedParams(22))

        diagnosticsToggle = TextView(this).apply {
            text = "＋  Connection details"
            textSize = 15f
            setTextColor(0xFF244768.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(15), dp(14), dp(15))
            background = roundedBackground(0xFFFFFFFF.toInt(), 0xFFE1E7EE.toInt())
            setOnClickListener {
                diagnosticsExpanded = !diagnosticsExpanded
                diagnosticsPanel.visibility = if (diagnosticsExpanded) View.VISIBLE else View.GONE
                text = if (diagnosticsExpanded) "−  Hide connection details" else "＋  Connection details"
            }
        }
        root.addView(diagnosticsToggle, spacedParams(8))
        diagnosticsPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        logView = TextView(this).apply {
            text = "No watch connected yet. Scan and select your watch."
            textSize = 12f
            setTextColor(0xFF33465B.toInt())
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = roundedBackground(0xFFFFFFFF.toInt(), 0xFFE1E7EE.toInt())
            setTextIsSelectable(true)
        }
        val logScroll = ScrollView(this).apply {
            isFillViewport = true
            addView(logView)
        }
        diagnosticsPanel.addView(logScroll, LinearLayout.LayoutParams(-1, dp(300)))
        root.addView(diagnosticsPanel)
        setContentView(screen)
    }

    private fun sectionTitle(label: String) = TextView(this).apply {
        text = label
        textSize = 19f
        setTextColor(0xFF192E49.toInt())
        setTypeface(null, android.graphics.Typeface.BOLD)
    }

    private fun metricRow(left: View, right: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(left, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(5) })
        addView(right, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(5) })
    }

    private fun metricCard(label: String, unit: String) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(15), dp(15), dp(16))
        background = roundedBackground(0xFFFFFFFF.toInt(), 0xFFE4EAF1.toInt())
        elevation = dp(2).toFloat()
        addView(TextView(this@MainActivity).apply {
            text = label
            textSize = 14f
            setTextColor(0xFF52657A.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        addView(TextView(this@MainActivity).apply {
            text = "—"
            textSize = 30f
            setTextColor(0xFF172D49.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, dp(8), 0, 0)
        })
        addView(TextView(this@MainActivity).apply {
            text = unit
            textSize = 12f
            setTextColor(0xFF728196.toInt())
        })
        addView(TextView(this@MainActivity).apply {
            text = "Not available yet"
            textSize = 12f
            setTextColor(0xFF718095.toInt())
            setPadding(0, dp(10), 0, 0)
        })
    }

    private fun roundedBackground(fill: Int, stroke: Int) = android.graphics.drawable.GradientDrawable().apply {
        shape = android.graphics.drawable.GradientDrawable.RECTANGLE
        cornerRadius = dp(18).toFloat()
        setColor(fill)
        setStroke(dp(1), stroke)
    }

    private fun spacedParams(bottom: Int) = LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
        bottomMargin = dp(bottom)
    }

    private fun makeButton(label: String, action: () -> Unit): Button = Button(this).apply {
        val primary = label == "Scan for watch"
        text = label
        isAllCaps = false
        setTextColor(if (primary) 0xFFFFFFFF.toInt() else 0xFF274968.toInt())
        background = roundedBackground(if (primary) 0xFF225C91.toInt() else 0xFFFFFFFF.toInt(), if (primary) 0xFF225C91.toInt() else 0xFFD5DEE8.toInt())
        elevation = if (primary) dp(2).toFloat() else 0f
        setOnClickListener { action() }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun hasPermissions() = neededPermissions.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 501 && hasPermissions()) refreshBluetoothStatus()
        else setStatus("Bluetooth permission is needed to scan and connect.")
    }

    private fun refreshBluetoothStatus() {
        val adapter = bluetoothAdapter
        when {
            adapter == null -> setStatus("This phone does not report Bluetooth support.")
            !adapter.isEnabled -> setStatus("Bluetooth is off. Turn it on in Samsung Settings, then scan.")
            else -> setStatus("Bluetooth is on. Turn on the watch, then scan.")
        }
    }

    @SuppressLint("MissingPermission")
    private fun startScan() {
        if (!hasPermissions()) { requestPermissions(neededPermissions, 501); return }
        val adapter = bluetoothAdapter
        if (adapter == null || !adapter.isEnabled) { refreshBluetoothStatus(); return }
        val bleScanner = adapter.bluetoothLeScanner
        if (bleScanner == null) { setStatus("BLE scanner unavailable. Check Bluetooth on this phone."); return }
        found.clear(); deviceList.removeAllViews(); scanner = true
        setStatus("Scanning for 12 seconds… Keep the watch charged and nearby.")
        appendLog("Starting Bluetooth Low Energy scan…")
        try {
            bleScanner.startScan(scanCallback)
            handler.postDelayed({ stopScan(); setStatus("Scan finished. Select the watch if it appeared.") }, 12_000)
        } catch (e: SecurityException) { setStatus("Bluetooth permission was denied.") }
    }

    @SuppressLint("MissingPermission")
    private fun stopScan() {
        if (!scanner) return
        scanner = false
        try { bluetoothAdapter?.bluetoothLeScanner?.stopScan(scanCallback) } catch (_: Exception) { }
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            val key = device.address ?: return
            if (found.containsKey(key)) return
            found[key] = device
            runOnUiThread {
                val name = try { device.name ?: result.scanRecord?.deviceName ?: "Unnamed Bluetooth device" } catch (_: SecurityException) { "Bluetooth device" }
                val item = Button(this@MainActivity).apply {
                    text = "$name\n${device.address}  •  signal ${result.rssi} dBm"
                    isAllCaps = false
                    gravity = Gravity.START or Gravity.CENTER_VERTICAL
                    setTextColor(0xFF274968.toInt())
                    background = roundedBackground(0xFFFFFFFF.toInt(), 0xFFD5DEE8.toInt())
                    setPadding(dp(16), dp(8), dp(16), dp(8))
                    elevation = dp(1).toFloat()
                    setOnClickListener { connect(device, name) }
                }
                deviceList.addView(item, LinearLayout.LayoutParams(-1, dp(62)).apply { bottomMargin = dp(4) })
                appendLog("Found: $name (${device.address}), signal ${result.rssi} dBm")
            }
        }
        override fun onScanFailed(errorCode: Int) { runOnUiThread { setStatus("Bluetooth scan failed (code $errorCode). Try again.") } }
    }

    @SuppressLint("MissingPermission")
    private fun connect(device: BluetoothDevice, displayName: String) {
        if (!hasPermissions()) { requestPermissions(neededPermissions, 501); return }
        stopScan()
        try { gatt?.close() } catch (_: Exception) { }
        selectedDevice = device
        setStatus("Connecting to $displayName…")
        appendLog("Connecting to $displayName (${device.address})")
        gatt = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE) else device.connectGatt(this, false, gattCallback)
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
            runOnUiThread {
                if (newState == BluetoothProfile.STATE_CONNECTED && statusCode == BluetoothGatt.GATT_SUCCESS) {
                    setStatus("Connected. Discovering watch services…")
                    appendLog("GATT connected; requesting services.")
                    if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) return@runOnUiThread
                    g.discoverServices()
                } else {
                    setStatus("Watch disconnected (status $statusCode).")
                    appendLog("Connection state changed: status=$statusCode, state=$newState")
                }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
            runOnUiThread {
                if (statusCode != BluetoothGatt.GATT_SUCCESS) { appendLog("Service discovery failed: $statusCode"); return@runOnUiThread }
                setStatus("Connected to " + (selectedDevice?.name ?: "watch") + " · " + g.services.size + " services found. Health readings are not decoded yet.")
                setStatus("Connected · " + g.services.size + " Bluetooth services found. Health readings are not decoded yet.")
                appendLog("Services discovered: ${g.services.size}")
                g.services.forEach { service ->
                    appendLog("SERVICE ${service.uuid}")
                    service.characteristics.forEach { c ->
                        val props = mutableListOf<String>()
                        if (c.properties and BluetoothGattCharacteristic.PROPERTY_READ != 0) props += "READ"
                        if (c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE != 0 || c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0) props += "WRITE"
                        if (c.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) props += "NOTIFY"
                        if (c.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0) props += "INDICATE"
                        appendLog("  CHAR ${c.uuid} [${props.joinToString()}]")
                        if (c.properties and BluetoothGattCharacteristic.PROPERTY_READ != 0) {
                            try { g.readCharacteristic(c) } catch (_: Exception) { appendLog("  Read request could not be queued") }
                        }
                        if (c.properties and (BluetoothGattCharacteristic.PROPERTY_NOTIFY or BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) {
                            tryEnableNotifications(g, c)
                        }
                    }
                }
                appendLog("Diagnostic scan complete. Values below are raw data; the watch's protocol must be identified before decoding health metrics.")
            }
        }

        @Suppress("DEPRECATION")
        override fun onCharacteristicRead(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, statusCode: Int) {
            if (statusCode == BluetoothGatt.GATT_SUCCESS) {
                val bytes = characteristic.value ?: byteArrayOf()
                runOnUiThread { appendLog("READ ${characteristic.uuid}: ${bytes.toHex()}") }
            }
        }

        override fun onCharacteristicRead(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray, statusCode: Int) {
            if (statusCode == BluetoothGatt.GATT_SUCCESS) runOnUiThread { appendLog("READ ${characteristic.uuid}: ${value.toHex()}") }
        }

        @Suppress("DEPRECATION")
        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            val bytes = characteristic.value ?: byteArrayOf()
            runOnUiThread { appendLog("NOTIFY ${characteristic.uuid}: ${bytes.toHex()}") }
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            runOnUiThread { appendLog("NOTIFY ${characteristic.uuid}: ${value.toHex()}") }
        }

        override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, statusCode: Int) {
            runOnUiThread { appendLog("Notification subscription ${descriptor.uuid}: status $statusCode") }
        }
    }

    @SuppressLint("MissingPermission")
    private fun tryEnableNotifications(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
        try {
            g.setCharacteristicNotification(c, true)
            val descriptor = c.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"))
            if (descriptor != null) {
                @Suppress("DEPRECATION")
                descriptor.value = if (c.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0) BluetoothGattDescriptor.ENABLE_INDICATION_VALUE else BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                @Suppress("DEPRECATION")
                g.writeDescriptor(descriptor)
            }
        } catch (e: Exception) { appendLog("Could not enable notifications for ${c.uuid}: ${e.message}") }
    }

    @SuppressLint("MissingPermission")
    private fun disconnect() {
        stopScan()
        try { gatt?.disconnect(); gatt?.close() } catch (_: Exception) { }
        gatt = null
        selectedDevice = null
        setStatus("Disconnected.")
        appendLog("Disconnected by user.")
    }

    private fun setStatus(message: String) { runOnUiThread { status.text = message } }
    private fun appendLog(message: String) {
        runOnUiThread {
            val current = logView.text.toString()
            val combined = if (current == "No watch connected yet. Scan and select your watch.") message else "$current\n$message"
            logView.text = combined.takeLast(14_000)
        }
    }
    private fun ByteArray.toHex(): String = if (isEmpty()) "(empty)" else joinToString(" ") { "%02X".format(it) }

    override fun onDestroy() {
        stopScan()
        try { gatt?.close() } catch (_: Exception) { }
        gatt = null
        super.onDestroy()
    }
}
